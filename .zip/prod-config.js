window.__ENV__ = {
  REACT_APP_INITIAL_URL: 'dashboards',
  REACT_APP_STATE_TYPE: 'context',
  REACT_APP_FILESTACK_KEY: 'Ach6MsgoQHGK6tCaq5uJgz',
  REACT_APP_LAYOUT: 'default',
  REACT_APP_MULTILINGUAL: 'true',
  REACT_APP_PRIMARY_COLOR: '#2997ff',
  REACT_APP_SECONDARY_COLOR: '#fb4f67',
  REACT_APP_THEME_MODE: 'light',
  REACT_APP_NAV_STYLE: 'mini-sidebar-onToggleSidebar',
  REACT_APP_LAYOUT_TYPE: 'full-width',
  REACT_APP_MIDDLEWARE: '',
};
