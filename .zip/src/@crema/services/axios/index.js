import axios from './ApiConfig';

export default axios;
