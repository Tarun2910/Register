export const dndData = [
  {
    id: '1000',
    name: 'Aysha Julka',
    handle: 'ayshajulkaji',
    image: '/assets/images/avatar/A1.jpg',
  },
  {
    id: '1001',
    name: 'Ayra Rovishi',
    handle: 'ayrarovishi',
    image: '/assets/images/avatar/A2.jpg',
  },
  {
    id: '1002',
    name: 'Sapna Awasthi',
    handle: 'sapnaawasthi',
    image: '/assets/images/avatar/A3.jpg',
  },
  {
    id: '1003',
    name: 'Sami Rudri',
    handle: 'samirudri',
    image: '/assets/images/avatar/A4.jpg',
  },
  {
    id: '1004',
    name: 'Brian Lara',
    handle: 'brianlara',
    image: '/assets/images/avatar/A5.jpg',
  },
  {
    id: '1005',
    name: 'Rickey Ponting',
    handle: 'rickeyponting',
    image: '/assets/images/avatar/A6.jpg',
  },
  {
    id: '1007',
    name: 'Smriti Mandhana',
    handle: 'smritimandhana',
    image: '/assets/images/avatar/A8.jpg',
  },
  {
    id: '1008',
    name: 'Aysha Julka',
    handle: 'benstokes',
    image: '/assets/images/avatar/A9.jpg',
  },
];
export default dndData;
